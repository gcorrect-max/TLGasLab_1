# ControlStack Web Bridge (LabVIEW ↔ Web Dashboard)

A complete example dashboard (React + TypeScript + Vite) that communicates with **LabVIEW** through a **WebView injection bridge**.

## Quick start
```bash
npm install
npm run dev
```
Open: `http://localhost:5173/`

## Production build (recommended for LabVIEW)
```bash
npm run build
npx serve dist -l 5173
```

## Auto-generate tags.json
```bash
npm run gen:tags
```

## Docs (English)
- `LABVIEW_INTEGRATION_EN.md`
- `LABVIEW_VI_COMMUNICATION_EN.md`
- `LabVIEW_WebBridge_Flow_EN.drawio`

## Upload to GitHub (CLI)
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/controlstack-web-bridge.git
git branch -M main
git push -u origin main
```
