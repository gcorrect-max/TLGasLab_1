# LabVIEW Integration Guide (WebView Bridge)

## Overview
This dashboard is designed to run inside a **LabVIEW WebView / embedded browser** where LabVIEW injects a JS API.

- **LabVIEW → Web (push):** `window.labviewBridge.updateState(...)`
- **Web → LabVIEW (commands):** `window.LabVIEW.FireUserEvent(refnum, json)`

Charts update **event-driven** when LabVIEW pushes tag updates. There is no WebSocket in this baseline design.

---

## Web side

### Development
```bash
npm install
npm run dev
```
Open: `http://localhost:5173/`

### Production build (recommended for LabVIEW)
```bash
npm run build
npx serve dist -l 5173
```

### Auto-generate tags configuration
```bash
npm run gen:tags
```

---

## LabVIEW side

### 1) Create a User Event for commands (Web → LabVIEW)
Create a LabVIEW **User Event** with payload type **string** (JSON). This produces a **refnum**.

### 2) Load the web UI in WebView
Load the dashboard URL (dev or a server hosting `dist/`).

### 3) Handshake: pass `refnum` to the page
After the page is loaded, execute:
```js
window.labviewBridge.setRefnum(12345)
```

### 4) Receive commands (Web → LabVIEW)
The page triggers:
```js
window.LabVIEW.FireUserEvent(refnum, '{"tag":"X","data":...}')
```
In LabVIEW: wait on the User Event, parse JSON, dispatch by `tag`.

### 5) Publish measurements (LabVIEW → Web)
Push updates:
```js
window.labviewBridge.updateState(JSON.stringify({ tag:"Motor_A_Speed", value:123.45, timestamp:Date.now() }))
```

### 6) Recommended rates and batching
- Typical UI rates: **5–30 Hz**
- For fast signals, send batches (`number[]`) every 100–200 ms.
