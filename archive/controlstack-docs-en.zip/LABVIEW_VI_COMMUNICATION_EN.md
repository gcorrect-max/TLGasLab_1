# LabVIEW ↔ Web Dashboard – Communication VI List

This document describes the **set of VIs (and suggested subVIs)** needed for communication between:
- the web page (React dashboard + `bridge.ts`)
- and code executed in LabVIEW (WebView / Embedded UI)

> VI names are a proposed “project standard”. Feel free to adapt them to your repo / naming conventions.

## Table of Contents
- [VI Index](#vi-index)
- [1) Start VI / Initialization](#1-start-vi--initialization)
- [2) Create UI→LabVIEW channel (User Event)](#2-create-uilabview-channel-user-event)
- [3) Open WebView and load the web page](#3-open-webview-and-load-the-web-page)
- [4) Handshake (pass refnum to the page)](#4-handshake-pass-refnum-to-the-page)
- [5) Command receive loop (Web → LabVIEW)](#5-command-receive-loop-web--labview)
- [6) Publish loop (LabVIEW → Web)](#6-publish-loop-labview--web)
- [7) Optional: waveform/batch publishing for charts](#7-optional-waveformbatch-publishing-for-charts)
- [8) Shutdown / cleanup](#8-shutdown--cleanup)
- [Minimal VI set (MVP)](#minimal-vi-set-mvp)
- [Example tags in this project](#example-tags-in-this-project)
- [Additional recommendation (for larger systems)](#additional-recommendation-for-larger-systems)

## VI Index

### Main VIs
- `WebUI_Main.vi`
- `WebUI_CreateUserEvent.vi`
- `WebUI_OpenWebView.vi`
- `WebUI_InjectHandshakeRefnum.vi`
- `WebUI_CommandEventLoop.vi`
- `WebUI_PublishLoop.vi`
- `WebUI_PublishWaveformBatch.vi` (optional)
- `WebUI_Shutdown.vi`

### SubVIs (helpers)
- `WebUI_ParseCommandJSON.vi`
- `WebUI_DispatchCommand.vi`
- `WebUI_BuildUpdateJSON.vi`
- `WebUI_InvokeUpdateStateJS.vi`

---

## 1) Start VI / Initialization

### **WebUI_Main.vi**
**Purpose:** Main VI that starts the whole communication layer and manages lifecycle.

**Tasks:**
- Initialize communication components (User Event, WebView, loops).
- Start loops:
  - **CommandEventLoop** (Web → LabVIEW)
  - **PublishLoop** (LabVIEW → Web)
- Handle stop/cleanup (close WebView, destroy User Event, stop loops).
- Optional: initialize “SystemStatus” (single source of truth) and registers/state.

**Inputs (example):**
- `WebURL` (e.g. `http://127.0.0.1:5173/` or URL hosting `dist/`)
- `PublishRateHz` (e.g. 10–30 Hz)
- `StrictValidation` (optional)

**Outputs (example):**
- `Status/Errors`
- `Refnum` (for debugging)

---

## 2) Create UI→LabVIEW channel (User Event)

### **WebUI_CreateUserEvent.vi**
**Purpose:** Create a User Event that the dashboard will fire via `FireUserEvent`.

**Tasks:**
- `Create User Event` with data type: **string (JSON)**.
- Register for events (if you use `Register For Events`).

**Outputs:**
- `User Event Refnum` – later passed to JS as **refnum**.

**Notes:**
- Simple command payload format: `{"tag":"X","data":...}`.

---

## 3) Open WebView and load the web page

### **WebUI_OpenWebView.vi**
**Purpose:** Open WebView / Embedded UI and load the dashboard page.

**Tasks:**
- Initialize the WebView control (depends on your technology).
- Load URL (dev server or production host of `dist/`).
- Wait for “page loaded” / “document ready”.

**Outputs:**
- WebView reference/handle (needed to execute JS).

---

## 4) Handshake (pass refnum to the page)

### **WebUI_InjectHandshakeRefnum.vi**
**Purpose:** Provide the page with refnum so the dashboard can send commands to LabVIEW.

**Tasks:**
- Execute JavaScript in WebView:
  ```js
  window.labviewBridge.setRefnum(<refnum>)
  ```

**When to call:**
- Only after the page is fully loaded (otherwise `window.labviewBridge` might not exist).

**Practical tip:**
- If WebView exposes `NavigationCompleted/DocumentComplete`, run the handshake in that callback.

---

## 5) Command receive loop (Web → LabVIEW)

### **WebUI_CommandEventLoop.vi**
**Purpose:** Receive commands from the dashboard and dispatch them to LabVIEW logic.

**Tasks:**
- Event Structure waiting on `User Event` (JSON string).
- Parse JSON into `{ tag, data }`.
- Dispatch actions based on `tag`.

**Suggested subVIs:**

#### **WebUI_ParseCommandJSON.vi**
**Purpose:** Parse the UI JSON string.

**Input:** `jsonString`  
**Output:** `tag` (string), `data` (Variant / string / cluster)

#### **WebUI_DispatchCommand.vi**
**Purpose:** Command router.

**Tasks:**
- `case structure` on `tag`
- Examples:
  - `Motor_A_Speed_Setpoint` → set controller setpoint
  - `Power_Main` → power on/off
  - `System_Command` → `RESET/START/STOP/...`

---

## 6) Publish loop (LabVIEW → Web)

### **WebUI_PublishLoop.vi**
**Purpose:** Periodically publish current measurements to the dashboard.

**Tasks:**
- Loop at a fixed frequency (e.g., 5–30 Hz).
- Read current values from sources.
- Build JSON update: `{"tag":"X","value":..., "timestamp": ...}`
- Execute JS:
  ```js
  window.labviewBridge.updateState(JSON.stringify({...}))
  ```

**Suggested subVIs:**

#### **WebUI_BuildUpdateJSON.vi**
Builds update JSON.

#### **WebUI_InvokeUpdateStateJS.vi**
Executes JS `updateState(...)`.

---

## 7) Optional: waveform/batch publishing for charts

### **WebUI_PublishWaveformBatch.vi**
**Purpose:** Publish fast signals as batches `number[]`.

**Tasks:**
- Buffer N samples and send an array update.

---

## 8) Shutdown / cleanup

### **WebUI_Shutdown.vi**
Stop loops, destroy User Event, close WebView, release resources.

---

## Minimal VI set (MVP)
1. `WebUI_Main.vi`
2. `WebUI_CreateUserEvent.vi`
3. `WebUI_OpenWebView.vi`
4. `WebUI_InjectHandshakeRefnum.vi`
5. `WebUI_CommandEventLoop.vi`
6. `WebUI_PublishLoop.vi`
7. `WebUI_Shutdown.vi`

---

## Example tags in this project
- `Motor_A_Speed` (LV → Web)
- `Drone_RF_Signal` (LV → Web, often `number[]`)
- `Power_Main` (Web → LV, boolean)
- `System_Command` (Web → LV, string)

---

## Additional recommendation (for larger systems)
Keep a “single source of truth”, e.g. `SystemStatus.ctl` / `SystemStatus.lvclass`.
