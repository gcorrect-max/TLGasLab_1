# LabVIEW Integration Guide (WebView Bridge)

## What this project assumes
This dashboard uses **LabVIEW WebView injection** (or an embedded browser control that exposes the LabVIEW API):
- LabVIEW provides `window.LabVIEW.FireUserEvent(refnum, jsonString)`
- LabVIEW calls into the page via:
  - `window.labviewBridge.setRefnum(refnum)`  (handshake)
  - `window.labviewBridge.updateState(json)` (push tag updates)

The React side does **not** use WebSocket by default. Charts update when LabVIEW pushes data.

---

## Web side (React/Vite)

### Development (fast iteration)
1. Install dependencies
   ```bash
   npm install
   ```
2. Start dev server
   ```bash
   npm run dev
   ```
3. Open in a browser
   - Local: `http://localhost:5173/`

> Dev server is meant for development only. For LabVIEW embedding, use the production build.

### Production build (recommended for LabVIEW WebView)
1. Build static files
   ```bash
   npm run build
   ```
2. Preview locally (optional)
   ```bash
   npm run preview
   ```

This creates `dist/` (static HTML/CSS/JS). You can host it:
- via a simple local HTTP server (recommended), or
- by loading `dist/index.html` directly (works sometimes, but CORS/path issues can appear).

**Simple HTTP server example (Node):**
```bash
npx serve dist -l 5173
```

### Auto-generate tags config
This project can generate `config/tags.json` from tag usage in code:
```bash
npm run gen:tags
```

How it detects tags:
- `useLabVIEW<number>('TAG', ...)`  => direction `labview_to_ui`, type inferred from `<number>`
- `bridge.sendToLabVIEW('TAG', ...)` => direction `ui_to_labview`, type best-effort inferred

---

## LabVIEW side (Handshake + Data Push)

### 1) Create a LabVIEW User Event
Create a User Event that your JS can fire back into LabVIEW. This gives you a **refnum**.

Typical flow:
1. Create User Event (`Create User Event`) with data type = **string** (JSON)
2. Get the User Event refnum (an integer-like identifier used by the WebView bridge)

### 2) Pass refnum to the page (Handshake)
After the page loads in the embedded browser, execute:
```js
window.labviewBridge.setRefnum(12345)
```

Where `12345` is your actual refnum.

If you cannot execute JS directly, you can call a WebView “Invoke Script” / “Execute JavaScript” API
(depending on your LabVIEW WebView/embedded browser control).

### 3) Handle UI → LabVIEW commands (FireUserEvent)
When React calls `bridge.sendToLabVIEW(tag, data)`, it triggers:
```js
window.LabVIEW.FireUserEvent(refnum, JSON.stringify({ tag, data }))
```

So LabVIEW should:
1. Wait on the User Event in an event structure
2. Receive a JSON string
3. Parse JSON:
   - `tag` (string)
   - `data` (any: number/string/boolean/object)

### 4) Push LabVIEW → UI updates (updateState)
Whenever LabVIEW has new measurements, push them into the UI:
```js
window.labviewBridge.updateState(JSON.stringify({
  tag: "Motor_A_Speed",
  value: 123.45,
  timestamp: Date.now()
}))
```

The bridge:
- stores the value in `bridge.store`
- notifies subscribers (React hooks), causing re-render and chart updates

### 5) Update rates / performance notes
- Best practice: send a reasonable update rate (e.g., 5–30 Hz for charts)
- If you need high-rate signals, send **batches** as arrays (number[]), and render as history windows.
- The connection indicator in the sidebar polls only the presence of the refnum; it does not affect charts.

---

## Troubleshooting

### `Connected` stays false
- LabVIEW did not call `setRefnum(...)`, or called it before the page finished loading.

### UI does not update
- Ensure you are calling `updateState(...)` with valid JSON and correct tag names.
- Check browser console for validation errors (type mismatch, etc.).

### `window.LabVIEW.FireUserEvent` missing
- You are running in a normal browser, not in LabVIEW WebView injection.
- Use the Controls page Simulation to test.
