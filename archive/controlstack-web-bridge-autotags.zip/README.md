# ControlStack Web Bridge (Example Project)

This repository is a **minimal, runnable** React + TypeScript dashboard that demonstrates
how a web UI can communicate with **LabVIEW** via a **WebView injection bridge**:
- LabVIEW -> JS: `window.labviewBridge.setRefnum(...)` (handshake) and `window.labviewBridge.updateState(...)` (push updates)
- JS -> LabVIEW: `window.LabVIEW.FireUserEvent(refnum, jsonString)` (commands/events)

> **Important:** In a normal browser (without LabVIEW WebView injection), `window.LabVIEW` does not exist.
> The UI still runs and you can **simulate** LabVIEW by using the built-in "Simulation" controls on the Controls page.

## Run (dev)
```bash
npm install
npm run dev
```

Open: http://localhost:5173/

## Build (prod)
```bash
npm run build
npm run preview
```

## Where to look
- `src/lib/bridge.ts` – the bridge singleton (store + pub/sub + FireUserEvent)
- `src/hooks/useLabVIEW.ts` – React hook that subscribes to tags and can send data back to LabVIEW
- `src/layouts/DashboardLayout.tsx` – layout with sidebar, routing, and connection status
- `src/views/Monitoring.tsx` – example charts updated from real tag streams (no UI polling required)
- `config/tags.json` – list of tags and expected types (with `_comment` field)

## LabVIEW payload formats
### LabVIEW -> UI (push)
Call in WebView JS:
```js
window.labviewBridge.updateState(JSON.stringify({ tag: "Output_Power_Factor", value: 0.97, timestamp: Date.now() }));
```

### UI -> LabVIEW (command)
UI calls:
```ts
bridge.sendToLabVIEW("Motor_A_Speed_Setpoint", 1200)
```
Which triggers:
```js
window.LabVIEW.FireUserEvent(refnum, JSON.stringify({ tag: "Motor_A_Speed_Setpoint", data: 1200 }))
```


## LabVIEW integration
See `docs/LabVIEW_INTEGRATION.md` for a step-by-step handshake + data push guide.


## Auto-generate config/tags.json
```bash
npm run gen:tags
```
