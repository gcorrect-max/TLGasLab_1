/**
 * TASKS OF THIS FILE
 * ------------------
 * Tiny reusable Card component for consistent panels across pages.
 */
import { ReactNode } from 'react';

export function Card(props: { title: string; children: ReactNode; right?: ReactNode }) {
  return (
    <section className="card">
      <header className="card-header">
        <h3>{props.title}</h3>
        <div className="card-right">{props.right}</div>
      </header>
      <div className="card-body">{props.children}</div>
    </section>
  );
}
