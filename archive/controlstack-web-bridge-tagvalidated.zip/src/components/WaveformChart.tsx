/**
 * TASKS OF THIS FILE
 * ------------------
 * Lightweight real-time line chart rendered as SVG.
 * - Accepts data[] and draws a path.
 * - Updates on React re-render (event-driven by tag updates).
 * - Uses no chart libraries to keep the embed footprint small.
 */
import { useMemo } from 'react';

export default function WaveformChart(props: { data: number[]; label: string; height?: number }) {
  const h = props.height ?? 140;
  const w = 480;

  const { path, min, max } = useMemo(() => {
    const data = props.data.length ? props.data : [0];
    let mn = data[0], mx = data[0];
    for (const v of data) { if (v < mn) mn = v; if (v > mx) mx = v; }
    const span = (mx - mn) || 1;

    const pts = data.map((v, i) => {
      const x = (i / Math.max(1, data.length - 1)) * (w - 20) + 10;
      const y = (1 - (v - mn) / span) * (h - 20) + 10;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    });

    return { path: `M ${pts.join(' L ')}`, min: mn, max: mx };
  }, [props.data, h]);

  return (
    <div className="waveform">
      <div className="waveform-head">
        <div className="waveform-label">{props.label}</div>
        <div className="waveform-range">min: {min.toFixed(3)} · max: {max.toFixed(3)}</div>
      </div>
      <svg width="100%" viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" className="waveform-svg" role="img">
        <path d={path} fill="none" stroke="currentColor" strokeWidth="2" />
      </svg>
    </div>
  );
}
