/**
 * TASKS OF THIS FILE
 * ------------------
 * - Defines the top-level Router structure.
 * - Wraps all pages inside DashboardLayout.
 */
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import DashboardLayout from './layouts/DashboardLayout';
import Overview from './views/Overview';
import Controls from './views/Controls';
import Monitoring from './views/Monitoring';
import Analytics from './views/Analytics';
import Settings from './views/Settings';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<DashboardLayout />}>
          <Route path="/" element={<Overview />} />
          <Route path="/controls" element={<Controls />} />
          <Route path="/monitoring" element={<Monitoring />} />
          <Route path="/analytics" element={<Analytics />} />
          <Route path="/settings" element={<Settings />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
