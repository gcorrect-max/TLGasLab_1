/**
 * TASKS OF THIS FILE
 * ------------------
 * React hook to treat a LabVIEW tag like a local React state variable.
 *
 * Behavior:
 * - Initializes from bridge.store cache if available.
 * - Subscribes to updates: bridge.subscribe(tag, cb).
 * - Returns [value, setValue].
 *   - setValue performs optimistic UI update and also sends a command to LabVIEW.
 */
import { useState, useEffect, useCallback } from 'react';
import bridge, { TagValue } from '../lib/bridge';

export function useLabVIEW<T = TagValue>(tag: string, initialValue: T): [T, (data: T) => void] {
  const [value, setValue] = useState<T>(() => {
    if (bridge.store.has(tag)) return bridge.store.get(tag) as T;
    return initialValue;
  });

  useEffect(() => {
    const unsubscribe = bridge.subscribe(tag, (newValue) => {
      setValue(newValue as T);
    });
    return () => unsubscribe();
  }, [tag]);

  const sendToLabVIEW = useCallback((data: T) => {
    setValue(data);
    bridge.sendToLabVIEW(tag, data);
  }, [tag]);

  return [value, sendToLabVIEW];
}
