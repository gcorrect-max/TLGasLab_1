/**
 * TASKS OF THIS FILE
 * ------------------
 * Maintains a fixed-size history window for scalar samples.
 * Each time `sample` changes, we append it and drop the oldest point.
 */
import { useEffect, useState } from 'react';

export function useRingBuffer(sample: number, size = 200) {
  const [data, setData] = useState<number[]>(() => Array(size).fill(0));

  useEffect(() => {
    setData((prev) => {
      const next = prev.slice(1);
      next.push(sample);
      return next;
    });
  }, [sample]);

  return data;
}
