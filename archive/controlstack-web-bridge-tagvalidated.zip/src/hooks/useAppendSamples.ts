/**
 * TASKS OF THIS FILE
 * ------------------
 * Maintains a fixed-size history window when LabVIEW sends batches (number[]).
 * Each time a new batch arrives, we append and trim to the last N points.
 */
import { useEffect, useState } from 'react';

export function useAppendSamples(samples: number[], size = 500) {
  const [data, setData] = useState<number[]>(() => Array(size).fill(0));

  useEffect(() => {
    if (!samples || samples.length === 0) return;
    setData((prev) => {
      const merged = prev.concat(samples);
      return merged.slice(Math.max(0, merged.length - size));
    });
  }, [samples, size]);

  return data;
}
