/**
 * TASKS OF THIS FILE
 * ------------------
 * Runtime tag registry + validator based on config/tags.json.
 *
 * Why:
 * - LabVIEW and Web UI communicate using {tag, value} or {tag, data} payloads.
 * - A typo in tag name or a wrong value type can silently break UI widgets.
 * - This module provides a single place to:
 *   1) map tag -> expected type/direction
 *   2) validate incoming (LabVIEW -> UI) updates
 *   3) validate outgoing (UI -> LabVIEW) commands
 *
 * Supported `type` strings in config/tags.json:
 * - "number" | "string" | "boolean" | "number[]" | "object"
 *
 * Supported `direction` strings:
 * - "labview_to_ui" | "ui_to_labview" | "both"
 */
import tagCfg from '../../config/tags.json';

export type TagType = 'number' | 'string' | 'boolean' | 'number[]' | 'object';
export type TagDirection = 'labview_to_ui' | 'ui_to_labview' | 'both';

export interface TagSpec {
  tag: string;
  type: TagType;
  direction: TagDirection;
  description?: string;
}

const registry = new Map<string, TagSpec>(
  (tagCfg as any).tags.map((t: any) => [t.tag, t as TagSpec])
);

export function getTagSpec(tag: string): TagSpec | undefined {
  return registry.get(tag);
}

function canAcceptFromLabVIEW(spec: TagSpec): boolean {
  return spec.direction === 'labview_to_ui' || spec.direction === 'both';
}

function canSendToLabVIEW(spec: TagSpec): boolean {
  return spec.direction === 'ui_to_labview' || spec.direction === 'both';
}

function validateType(expected: TagType, value: unknown): boolean {
  switch (expected) {
    case 'number':
      return typeof value === 'number' && Number.isFinite(value);
    case 'string':
      return typeof value === 'string';
    case 'boolean':
      return typeof value === 'boolean';
    case 'number[]':
      return Array.isArray(value) && value.every((v) => typeof v === 'number' && Number.isFinite(v));
    case 'object':
      return typeof value === 'object' && value !== null && !Array.isArray(value);
    default:
      return false;
  }
}

export function validateIncoming(tag: string, value: unknown): { ok: boolean; reason?: string } {
  const spec = getTagSpec(tag);
  if (!spec) {
    return { ok: true, reason: 'unknown_tag' }; // allow unknown tags (warn in bridge)
  }
  if (!canAcceptFromLabVIEW(spec)) {
    return { ok: false, reason: `tag_not_allowed_from_labview (direction=${spec.direction})` };
  }
  if (!validateType(spec.type, value)) {
    return { ok: false, reason: `type_mismatch expected=${spec.type}` };
  }
  return { ok: true };
}

export function validateOutgoing(tag: string, data: unknown): { ok: boolean; reason?: string } {
  const spec = getTagSpec(tag);
  if (!spec) {
    return { ok: true, reason: 'unknown_tag' }; // allow unknown tags (warn in bridge)
  }
  if (!canSendToLabVIEW(spec)) {
    return { ok: false, reason: `tag_not_allowed_to_labview (direction=${spec.direction})` };
  }
  if (!validateType(spec.type, data)) {
    return { ok: false, reason: `type_mismatch expected=${spec.type}` };
  }
  return { ok: true };
}
