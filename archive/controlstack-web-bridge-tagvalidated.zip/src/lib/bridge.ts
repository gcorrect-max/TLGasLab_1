/**
 * TASKS OF THIS FILE
 * ------------------
 * Central "Web Bridge" singleton connecting React UI with LabVIEW (WebView injection).
 *
 * Provides:
 * 1) store: Map<tag, value> (last-known value)
 * 2) subscribe(tag, cb): pub/sub for updates
 * 3) setRefnum(...): handshake from LabVIEW
 * 4) updateState(...): data push from LabVIEW to UI
 * 5) sendToLabVIEW(tag, data): UI -> LabVIEW via window.LabVIEW.FireUserEvent
 *
 * LabVIEW integration expectations:
 * - LabVIEW calls: window.labviewBridge.setRefnum(12345)
 * - LabVIEW calls: window.labviewBridge.updateState('{"tag":"X","value":123}')
 * - UI calls: bridge.sendToLabVIEW("Some_Setpoint", 1.23)
 *
 * In a normal browser (no LabVIEW injection), window.LabVIEW is missing.
 * The UI still runs; use the Simulation tools on the Controls page.
 */

import { validateIncoming, validateOutgoing } from './tagRegistry';

export type TagValue = number | string | boolean | number[] | Record<string, unknown>;

interface LabVIEWUpdatePayload {
  tag: string;
  value: TagValue;
  timestamp?: number;
}

interface WebToLabVIEWPayload {
  tag: string;
  data: unknown;
}

declare global {
  interface Window {
    LabVIEW?: {
      FireUserEvent: (refnum: number, jsonString: string) => void;
    };
    labviewBridge: ControlStackBridge;
  }
}

class ControlStackBridge {
  private refnum: number | null = null;
  public store: Map<string, TagValue> = new Map();
  private subscribers: Map<string, Set<(value: TagValue) => void>> = new Map();

  public setRefnum(args: number | string | { refnum: number }) {
    let extracted: number | null = null;

    try {
      if (typeof args === 'number') {
        extracted = args;
      } else if (typeof args === 'object' && args !== null && 'refnum' in args) {
        extracted = (args as any).refnum;
      } else if (typeof args === 'string') {
        try {
          const parsed = JSON.parse(args);
          if (typeof parsed === 'object' && parsed !== null && 'refnum' in parsed) {
            extracted = (parsed as any).refnum;
          } else if (typeof parsed === 'number') {
            extracted = parsed;
          }
        } catch {
          extracted = Number.parseFloat(args);
        }
      }

      if (extracted !== null && !Number.isNaN(extracted)) {
        console.log(`[CS-WebBridge] Handshake established. Refnum: ${extracted}`);
        this.refnum = extracted;
        return `Connected to Refnum: ${extracted}`;
      }

      console.error('[CS-WebBridge] Invalid refnum received:', args);
      return `Error: Invalid refnum ${JSON.stringify(args)}`;
    } catch (e) {
      console.error('[CS-WebBridge] Error processing setRefnum:', e);
      return `Error: ${String(e)}`;
    }
  }

  public updateState(jsonString: string | LabVIEWUpdatePayload) {
    try {
      const payload: LabVIEWUpdatePayload =
        typeof jsonString === 'string' ? JSON.parse(jsonString) : jsonString;

      const { tag, value } = payload;

      const vIn = validateIncoming(tag, value);
      if (!vIn.ok) {
        console.warn(`[CS-WebBridge] Incoming update rejected for tag="${tag}": ${vIn.reason}`, value);
        return;
      }
      if (vIn.reason === 'unknown_tag') {
        console.warn(`[CS-WebBridge] Incoming update for unknown tag="${tag}" (not in config/tags.json).`, value);
      }


      this.store.set(tag, value);

      const set = this.subscribers.get(tag);
      if (set) set.forEach((cb) => cb(value));
    } catch (e) {
      console.error('[CS-WebBridge] Failed to parse updateState payload', e);
    }
  }

  public subscribe(tag: string, callback: (value: TagValue) => void) {
    if (!this.subscribers.has(tag)) {
      this.subscribers.set(tag, new Set());
    }
    this.subscribers.get(tag)!.add(callback);

    if (this.store.has(tag)) {
      callback(this.store.get(tag)!);
    }

    return () => {
      this.subscribers.get(tag)?.delete(callback);
    };
  }

  public sendToLabVIEW(tag: string, data: unknown) {
    if (this.refnum === null) {
      console.warn('[CS-WebBridge] Cannot send to LabVIEW: Handshake not established (Refnum missing).');
      return;
    }

    const vOut = validateOutgoing(tag, data);
    if (!vOut.ok) {
      console.error(`[CS-WebBridge] Outgoing send rejected for tag="${tag}": ${vOut.reason}`, data);
      return;
    }
    if (vOut.reason === 'unknown_tag') {
      console.warn(`[CS-WebBridge] Outgoing send for unknown tag="${tag}" (not in config/tags.json).`, data);
    }

    const payload: WebToLabVIEWPayload = { tag, data };
    const jsonString = JSON.stringify(payload);

    if (window.LabVIEW?.FireUserEvent) {
      window.LabVIEW.FireUserEvent(this.refnum, jsonString);
      console.log(`[CS-WebBridge] Sent to Ref ${this.refnum}:`, payload);
    } else {
      console.warn('[CS-WebBridge] window.LabVIEW.FireUserEvent is missing. Are we running inside LabVIEW WebView?');
    }
  }

  public getRefnum() {
    return this.refnum;
  }
}

const bridge = new ControlStackBridge();
window.labviewBridge = bridge;

export default bridge;
