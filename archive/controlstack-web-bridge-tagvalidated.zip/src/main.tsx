/**
 * TASKS OF THIS FILE
 * ------------------
 * - Application entry point.
 * - Attaches the React tree to the DOM (#root).
 * - Imports global styles.
 */
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles/global.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
