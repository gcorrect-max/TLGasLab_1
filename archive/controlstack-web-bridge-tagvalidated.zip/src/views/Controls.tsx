/**
 * TASKS OF THIS FILE
 * ------------------
 * Controls page aligned 1:1 with tag names from the provided example archive:
 * - Motor_A_Speed (number, direction: both)
 * - Power_Main (boolean, direction: both)
 * - System_Command (string, direction: ui_to_labview)
 *
 * Also includes simulation buttons:
 * - setRefnum(...) to emulate LabVIEW handshake
 * - updateState(...) to emulate LabVIEW pushing values
 *
 * Type validation is enforced by src/lib/tagRegistry.ts and used in bridge.ts.
 */
import { useMemo, useState } from 'react';
import { Card } from '../components/Card';
import bridge from '../lib/bridge';
import { useLabVIEW } from '../hooks/useLabVIEW';

function nowMs() { return Date.now(); }

export default function Controls() {
  const [speed, setSpeed] = useLabVIEW<number>('Motor_A_Speed', 0);
  const [power, setPower] = useLabVIEW<boolean>('Power_Main', true);
  const [, setSystemCommand] = useLabVIEW<string>('System_Command', '');

  const [cmd, setCmd] = useState<string>('RESET');

  const canSend = bridge.getRefnum() !== null;

  const help = useMemo(() => {
    return `In LabVIEW WebView, call:
- window.labviewBridge.setRefnum(12345)
- window.labviewBridge.updateState(JSON.stringify({tag:"Motor_A_Speed", value: 1200}))
- window.labviewBridge.updateState(JSON.stringify({tag:"Power_Main", value: true}))
- window.labviewBridge.updateState(JSON.stringify({tag:"Drone_RF_Signal", value: [1,2,3,2,1]}))
`;
  }, []);

  return (
    <div className="grid">
      <Card title="Motor_A_Speed (both)" right={<span className={`pill ${canSend ? 'ok' : 'bad'}`}>{canSend ? 'ready' : 'no refnum'}</span>}>
        <p>Change the speed value from UI (sent to LabVIEW).</p>
        <div className="row">
          <input className="input" type="number" value={speed} onChange={(e) => setSpeed(Number(e.target.value))} />
        </div>
        <p className="muted">Expected type: <code>number</code>.</p>
      </Card>

      <Card title="Power_Main (both)" right={<span className={`pill ${canSend ? 'ok' : 'bad'}`}>{canSend ? 'ready' : 'no refnum'}</span>}>
        <p>Toggle power state (boolean).</p>
        <div className="row">
          <button className="button" onClick={() => setPower(!power)} disabled={!canSend}>
            Toggle Power ({String(power)})
          </button>
        </div>
        <p className="muted">Expected type: <code>boolean</code>.</p>
      </Card>

      <Card title="System_Command (ui_to_labview)" right={<span className={`pill ${canSend ? 'ok' : 'bad'}`}>{canSend ? 'ready' : 'no refnum'}</span>}>
        <p>Send a command string to LabVIEW.</p>
        <div className="row">
          <input className="input" value={cmd} onChange={(e) => setCmd(e.target.value)} />
          <button className="button" onClick={() => setSystemCommand(cmd)} disabled={!canSend}>
            Send command
          </button>
        </div>
        <p className="muted">Expected type: <code>string</code>.</p>
      </Card>

      <Card title="Simulation (normal browser)">
        <div className="row">
          <button className="button" onClick={() => bridge.setRefnum(12345)}>Simulate setRefnum(12345)</button>
          <button className="button" onClick={() => bridge.updateState({ tag: 'Motor_A_Speed', value: Math.random() * 2000, timestamp: nowMs() })}>
            Push Motor_A_Speed random
          </button>
          <button className="button" onClick={() => bridge.updateState({ tag: 'Power_Main', value: Math.random() > 0.5, timestamp: nowMs() })}>
            Push Power_Main random
          </button>
          <button className="button" onClick={() => bridge.updateState({ tag: 'Drone_RF_Signal', value: Array.from({length: 64}, (_, i) => Math.sin(i / 6) + (Math.random()-0.5)*0.2), timestamp: nowMs() })}>
            Push Drone_RF_Signal waveform
          </button>
        </div>

        <pre className="code">{help}</pre>
      </Card>
    </div>
  );
}
