/**
 * TASKS OF THIS FILE
 * ------------------
 * Monitoring page aligned 1:1 with tag names from the provided example archive:
 * - Motor_A_Speed (number)
 * - Drone_RF_Signal (number[])
 *
 * Update mechanism:
 * - Event-driven for tag values: LabVIEW -> bridge.updateState -> useLabVIEW -> re-render.
 * - For Motor_A_Speed we keep a browser-side history window (ring buffer) for charting.
 * - For Drone_RF_Signal we draw the waveform array directly.
 *
 * IMPORTANT:
 * - No WebSocket here.
 * - No polling for chart data.
 * - The only polling in the app is the connection indicator (refnum presence) in DashboardLayout.
 */
import { Card } from '../components/Card';
import WaveformChart from '../components/WaveformChart';
import { useLabVIEW } from '../hooks/useLabVIEW';
import { useRingBuffer } from '../hooks/useRingBuffer';
import uiCfg from '../../config/ui.json';

export default function Monitoring() {
  const windowSize = uiCfg.chart?.windowSize ?? 200;

  const [speed] = useLabVIEW<number>('Motor_A_Speed', 0);
  const [rf] = useLabVIEW<number[]>('Drone_RF_Signal', [0, 0, 0, 0, 0]);

  const speedHistory = useRingBuffer(speed, windowSize);

  return (
    <div className="grid">
      <Card title="Motor A Speed (history)">
        <WaveformChart data={speedHistory} label="Motor_A_Speed" />
        <p className="muted">
          Source tag: <code>Motor_A_Speed</code> (number).
        </p>
      </Card>

      <Card title="Drone RF Signal (waveform)">
        <WaveformChart data={rf} label="Drone_RF_Signal" />
        <p className="muted">
          Source tag: <code>Drone_RF_Signal</code> (number[]).
        </p>
      </Card>
    </div>
  );
}
