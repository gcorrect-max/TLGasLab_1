/**
 * TASKS OF THIS FILE
 * ------------------
 * - Overview page showing a live numeric tag.
 * - Demonstrates useLabVIEW() for read-only use.
 */
import { Card } from '../components/Card';
import { useLabVIEW } from '../hooks/useLabVIEW';

export default function Overview() {
  const [speed] = useLabVIEW<number>('Motor_A_Speed', 0);

  return (
    <div className="grid">
      <Card title="Live Tag: Motor_A_Speed">
        <p>This value updates when LabVIEW pushes updates via <code>updateState</code>.</p>
        <div className="big-number">{speed.toFixed(2)}</div>
      </Card>

      <Card title="No LabVIEW? Use Simulation">
        <p>Go to <b>Controls</b> and use Simulation buttons to set a fake refnum and push fake values.</p>
      </Card>
    </div>
  );
}
