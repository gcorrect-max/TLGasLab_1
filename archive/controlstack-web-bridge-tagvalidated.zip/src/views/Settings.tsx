/**
 * TASKS OF THIS FILE
 * ------------------
 * Settings page:
 * - Displays the JSON configuration files used by this project.
 * - In a production system, this could become an editable settings UI.
 */
import { Card } from '../components/Card';
import navCfg from '../../config/navigation.json';
import tagCfg from '../../config/tags.json';
import uiCfg from '../../config/ui.json';

export default function Settings() {
  return (
    <div className="grid">
      <Card title="Navigation config (config/navigation.json)">
        <pre className="code">{JSON.stringify(navCfg, null, 2)}</pre>
      </Card>

      <Card title="Tags config (config/tags.json)">
        <pre className="code">{JSON.stringify(tagCfg, null, 2)}</pre>
      </Card>

      <Card title="UI config (config/ui.json)">
        <pre className="code">{JSON.stringify(uiCfg, null, 2)}</pre>
      </Card>
    </div>
  );
}
