/**
 * TASKS OF THIS FILE
 * ------------------
 * Analytics placeholder aligned to archive tags.
 * Demonstrates derived metrics from:
 * - Motor_A_Speed
 * - Power_Main
 */
import { Card } from '../components/Card';
import { useLabVIEW } from '../hooks/useLabVIEW';

export default function Analytics() {
  const [speed] = useLabVIEW<number>('Motor_A_Speed', 0);
  const [power] = useLabVIEW<boolean>('Power_Main', true);

  const derived = power ? speed / 100.0 : 0;

  return (
    <div className="grid">
      <Card title="Current values and derived KPI">
        <div className="row">
          <div className="kv"><div className="k">Motor_A_Speed</div><div className="v">{speed.toFixed(2)}</div></div>
          <div className="kv"><div className="k">Power_Main</div><div className="v">{String(power)}</div></div>
          <div className="kv"><div className="k">Derived</div><div className="v">{derived.toFixed(4)}</div></div>
        </div>
        <p className="muted">Replace derived logic with your real domain calculations.</p>
      </Card>
    </div>
  );
}
