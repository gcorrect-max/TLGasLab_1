/**
 * TASKS OF THIS FILE
 * ------------------
 * - Main dashboard layout: sidebar + top appbar + content area.
 * - Sidebar navigation is loaded from JSON: config/navigation.json.
 * - Connection status checks if LabVIEW handshake exists (bridge.getRefnum()).
 * - Uses polling every `ui.connection.statusPollMs` only for the CONNECTED indicator.
 *
 * Note:
 * - Charts are NOT updated by this polling.
 * - Charts update when LabVIEW pushes tag updates to bridge.updateState().
 */
import { useEffect, useMemo, useState } from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Sliders,
  Activity,
  BarChart3,
  Settings as SettingsIcon,
  Menu,
  X,
  Wifi,
  WifiOff,
} from 'lucide-react';
import bridge from '../lib/bridge';
import navCfg from '../../config/navigation.json';
import uiCfg from '../../config/ui.json';

type IconKey = 'LayoutDashboard' | 'Sliders' | 'Activity' | 'BarChart3' | 'Settings';

const ICONS: Record<IconKey, any> = {
  LayoutDashboard,
  Sliders,
  Activity,
  BarChart3,
  Settings: SettingsIcon,
};

export default function DashboardLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [connected, setConnected] = useState(bridge.getRefnum() !== null);
  const location = useLocation();

  const statusPollMs = uiCfg.connection?.statusPollMs ?? 1000;

  useEffect(() => {
    const interval = setInterval(() => {
      setConnected(bridge.getRefnum() !== null);
    }, statusPollMs);
    return () => clearInterval(interval);
  }, [statusPollMs]);

  const navigation = useMemo(() => {
    return (navCfg.items || []).map((it: any) => ({
      name: it.name as string,
      path: it.path as string,
      Icon: ICONS[(it.iconKey as IconKey) || 'Activity'] ?? Activity,
    }));
  }, []);

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  const pageTitle = navigation.find((n) => isActive(n.path))?.name || 'Dashboard';

  return (
    <div className="dashboard-container">
      <aside className={`dashboard-sidebar ${!sidebarOpen ? 'collapsed' : ''}`}>
        <div className="sidebar-brand">
          <div className="brand-icon">
            <Activity size={24} color="white" />
          </div>
          <div className="brand-text">
            <h1>ControlStack</h1>
            <p>Web Bridge v1.0</p>
          </div>
        </div>

        <nav className="sidebar-nav">
          <ul className="nav-list">
            {navigation.map(({ name, path, Icon }) => (
              <li key={path} className="nav-item">
                <Link to={path} className={`nav-link ${isActive(path) ? 'active' : ''}`}>
                  <Icon size={20} />
                  <span>{name}</span>
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className="sidebar-status">
          <div className={`status-card ${connected ? 'ok' : 'bad'}`}>
            {connected ? <Wifi size={16} /> : <WifiOff size={16} />}
            <div className="status-text">
              <div className="status-title">{connected ? 'Connected' : 'Disconnected'}</div>
              <div className="status-sub">
                {connected ? `Refnum: ${bridge.getRefnum()}` : 'No LabVIEW connection'}
              </div>
            </div>
          </div>
        </div>
      </aside>

      <div className="dashboard-main">
        <header className="dashboard-appbar">
          <button className="icon-button" onClick={() => setSidebarOpen(!sidebarOpen)} aria-label="Toggle sidebar">
            {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
          </button>

          <div className="appbar-title">
            <h2>{pageTitle}</h2>
          </div>

          <div className="appbar-right">
            <span className="clock">{new Date().toLocaleTimeString()}</span>
          </div>
        </header>

        <main className="dashboard-content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
