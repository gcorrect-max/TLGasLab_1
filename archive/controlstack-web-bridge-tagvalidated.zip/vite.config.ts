/**
 * TASKS OF THIS FILE
 * ------------------
 * - Provides Vite build/dev configuration for this example project.
 * - Uses the React plugin to support JSX/TSX and Fast Refresh.
 * - Keeps configuration minimal to highlight the LabVIEW bridge parts.
 */
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()]
});
